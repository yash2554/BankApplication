package com.fdmgroup.banktest;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import com.fdmgroup.bankapp.BankAccount;
import com.fdmgroup.bankapp.CheckingAccount;
import com.fdmgroup.bankapp.PersonalCustomer;

public class CheckingAccountTest {

	PersonalCustomer personalCust;
	BankAccount bankAccount;

	@Before
	public void setUp() throws Exception {
		personalCust = new PersonalCustomer("Yash", "2121", "Jersey City", 232);
		bankAccount = new CheckingAccount(personalCust);
	}

	@Test
	public void testDepositmethod_checkBalance_Input1000_Return1000() {
		personalCust.deposit(bankAccount, new BigDecimal(1000));
		assertEquals(new BigDecimal(1000), bankAccount.getBalance());
	}

	@Test
	public void test_withdraw_method_with_deposite() {
		BigDecimal depositAmount = new BigDecimal(1000);
		personalCust.deposit(bankAccount, depositAmount);
		personalCust.deposit(bankAccount, new BigDecimal(500));
		// System.out.println(bankAccount.getBalance());
		BigDecimal withAmount = new BigDecimal(500);
		// System.out.println(bankAccount.getBalance());
		personalCust.withdraw(bankAccount, withAmount);
		//System.out.println(bankAccount.getBalance());
		assertEquals(depositAmount, bankAccount.getBalance());
	}

}
