package com.fdmgroup.banktest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ BankTest.class, CheckingAccountTest.class, PersonalCustomerTest.class, SavingsAccountTest.class })
public class AllTests {

}
