package com.fdmgroup.banktest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.fdmgroup.bankapp.BankAccount;
import com.fdmgroup.bankapp.BankCustomer;
import com.fdmgroup.bankapp.CheckingAccount;
import com.fdmgroup.bankapp.CompanyCustomer;
import com.fdmgroup.bankapp.PersonalCustomer;
import com.fdmgroup.bankapp.SavingsAccount;

import static org.mockito.Mockito.*;

public class BankTest {

	BankCustomer customer_one;
	BankCustomer customer_two;
	BankCustomer customer_three;

	BankAccount checkingAcc;
	BankAccount savingsAcc;

	PersonalCustomer personalCust;
	CompanyCustomer companyCust;

	@Before
	public void setUp() throws Exception {
		customer_one = new PersonalCustomer("Jay", "2222", "New Jersey", 243);
		customer_two = new CompanyCustomer("Dev", "1342", "Manhattan", 209);
		customer_three = new CompanyCustomer("Sam", "1342", "Manhattan", 122);
	}

	@Test
	public void test_new_Customer_Increment() {
		int expected = 2000007;
		// System.out.println(customer_three.getCustomerId());
		assertEquals(expected, customer_two.getCustomerId());
	}

	@Test
	public void test_newBankAccount_Increment() {
		personalCust = mock(PersonalCustomer.class);
		companyCust = mock(CompanyCustomer.class);

		checkingAcc = new CheckingAccount(personalCust);
		savingsAcc = new SavingsAccount(companyCust);
		int expected = 1005;
		assertEquals(expected, savingsAcc.getID());
	}

}
