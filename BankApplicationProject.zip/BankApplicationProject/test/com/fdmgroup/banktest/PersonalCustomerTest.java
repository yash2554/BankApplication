package com.fdmgroup.banktest;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import com.fdmgroup.bankapp.BankAccount;
import com.fdmgroup.bankapp.PersonalCustomer;
import com.fdmgroup.bankapp.SavingsAccount;

public class PersonalCustomerTest {

	PersonalCustomer personalCust1, personalCust2;
	BankAccount savingsAcc;

	@Before
	public void setUp() throws Exception {
		personalCust1 = new PersonalCustomer("Yash", "432", "Jersey City", 2212);
		personalCust2 = new PersonalCustomer("Alex", "231", "Bronx", 2132);
	}

	@Test
	public void test_ResetAccount_Method_Input_Account_Return_Zero() {

		savingsAcc = new SavingsAccount(personalCust1);
		personalCust1.deposit(savingsAcc, new BigDecimal(1000));
		personalCust1.resetAccount();

		assertEquals(savingsAcc.getBalance(), BigDecimal.ZERO);
	}

	@Test
	public void test_Withdraw_Input_More_Than_Current_Error_Return_Insufficient() {

		savingsAcc = new SavingsAccount(personalCust2);
		personalCust2.deposit(savingsAcc, new BigDecimal(100));
		personalCust2.withdraw(savingsAcc, new BigDecimal(150));
		assertEquals(savingsAcc.getBalance(), new BigDecimal(100));
	}

}
