package com.fdmgroup.bankapp;

import java.math.BigDecimal;

public class SavingsAccount extends BankAccount {
	private BigDecimal interest;

	public SavingsAccount(CompanyCustomer cust) {
		super(cust);
		this.interest = new BigDecimal(0);
	}
	public SavingsAccount(PersonalCustomer pers) {
		super(pers);
		this.interest = new BigDecimal(0);
	}

	public BigDecimal withdraw(BigDecimal amount) {
		if (amount.compareTo(BigDecimal.ZERO) <= 0) {
			System.out.println("Error:Enter a valid amount");
			return new BigDecimal(0);
		} else {
			if (super.getBalance().subtract(amount).compareTo(BigDecimal.ZERO) < 0) {
				System.out.println("Insufficient fund");
				return new BigDecimal(0);
			} else {
				BigDecimal balance = super.getBalance().subtract(amount);
				super.setBalance(balance);
				System.out.println("You have withdrawn " + amount + " and your balance is now " + balance);
				return balance;
			}
		}
	}

	public BigDecimal getInterest() {
		return interest;
	}

	public void setInterest(BigDecimal interest) {
		this.interest = interest;
	}

}
