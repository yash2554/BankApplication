package com.fdmgroup.bankapp;

import java.math.BigDecimal;

public class CompanyCustomer extends BankCustomer {

	public CompanyCustomer(String name, String ssn, String address, int taxId) {
		super(name,ssn, address, taxId);
	}

	public void depositAll(BigDecimal amount) {
		for (BankAccount account : accounts) {
			account.deposit(amount);
		}
	}
}
