package com.fdmgroup.bankapp;

import java.math.BigDecimal;

import com.fdmgroup.bankapp.BankCustomer;

public abstract class BankAccount {
	private BigDecimal balance = new BigDecimal(0);
	private static int NUMBER_OF_ACCOUNT = 1000;
	private static final int COUNT = 5;
	private final String bAcc = "Business";
	private final String pAcc = "Personal";
	private final int ID;
	private BankCustomer owner;
	private String type;
	private double interest=0;

	public BankAccount(CompanyCustomer cust) {
		this.ID = NUMBER_OF_ACCOUNT;
		NUMBER_OF_ACCOUNT += COUNT;
		this.owner = cust;
		this.setType(bAcc);
		owner.addAccount(this);
	}

	public BankAccount(PersonalCustomer per) {
		this.ID = NUMBER_OF_ACCOUNT;
		NUMBER_OF_ACCOUNT += COUNT;
		this.owner = per;
		this.setType(pAcc);
		owner.addAccount(this);
	}

	public BigDecimal deposit(BigDecimal amount) {
		if (amount.compareTo(BigDecimal.ZERO) <= 0 || amount.equals(null)) {
			System.out.println("Error:Enter a valid amount");
			return new BigDecimal(0);
		} else {
			checkInterest(amount);
			amount = amount.add(amount.multiply(new BigDecimal(interest)));
			this.balance = this.balance.add(amount);
			System.out.println("You have deosited " + amount + " and your balance is now " + balance);
			return balance;
		}
	}
	public double checkInterest(BigDecimal amount){
		if((balance.add(amount)).compareTo(BigDecimal.ZERO)>10000){
			interest=0;
		}else{
			interest=0;
		}
		return interest;
	}
	public abstract BigDecimal withdraw(BigDecimal amount);

	public BankCustomer getOwner() {
		return owner;
	}

	public void setOwner(BankCustomer owner) {
		this.owner = owner;
	}

	public int getID() {
		return ID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

}
