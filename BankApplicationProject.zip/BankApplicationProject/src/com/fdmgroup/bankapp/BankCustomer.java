package com.fdmgroup.bankapp;

import java.math.BigDecimal;
import java.util.ArrayList;



public abstract class BankCustomer {
	private static int NUM_CUSTOMER = 2000000;
	private  static final int CCOUNT = 7;
	private String name;
	private String ssn;
	private String address;
	private int taxId;
	private int customerId ;
	protected ArrayList<BankAccount> accounts = new ArrayList<BankAccount>(0);

	public BankCustomer(String name, String ssn, String address, int taxId) {
		super();
		this.setName(name);
		this.setAddress(address);
		this.setSsn(ssn);
		this.setTaxId(taxId);
		this.setCustomerId(NUM_CUSTOMER);
		NUM_CUSTOMER += CCOUNT;
	}

	public void addAccount(BankAccount account){
		accounts.add(account);
	}
	public void removeAccount(BankAccount account){
		for(int start=0;start<accounts.size();start++){
			if(accounts.get(start)==account){
				accounts.remove(start);
			}
		}
	}
	public void removeAllAccounts() {
		for (BankAccount account : accounts)
			accounts.remove(account);
	}
	
	public void deposit(BankAccount account, BigDecimal amount){
		if(account == null || amount == null){
			System.out.println("Invalid Argument");
		}else if(accounts.contains(account)){
			account.deposit(amount);
		}
		else{
			System.out.println("Invalid Argument");
		}
	}
	
	public void withdraw(BankAccount account, BigDecimal amount){
		if(account == null || amount == null){
			System.out.println("Invalid Argument");
		}else if(accounts.contains(account))
			{account.withdraw(amount);
			}else{
				System.out.println("Invalid Argument");
			}
			
	}
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getTaxId() {
		return taxId;
	}

	public void setTaxId(int taxId) {
		this.taxId = taxId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	

}
