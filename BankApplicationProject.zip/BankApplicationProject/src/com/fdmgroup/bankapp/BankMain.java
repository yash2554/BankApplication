package com.fdmgroup.bankapp;

import java.math.BigDecimal;
import java.util.Scanner;

public class BankMain {
	
	Scanner consoleInput;
	static String name;
	static String ssn;
	static String address;
	static int taxId;

	public static void main(String[] args) {

		BankMain bank = new BankMain();
		bank.mainMenu();
		PersonalCustomer person = new PersonalCustomer(name, ssn, address, taxId);
		SavingsAccount saving = new SavingsAccount(person);
		BigDecimal initialDeposit = new BigDecimal(10000);

		person.deposit(saving, initialDeposit);
		person.withdraw(saving, new BigDecimal(1200));
		person.deposit(saving, new BigDecimal(8760));
		person.withdraw(saving, new BigDecimal(100));
		// System.out.println(saving.getBalance());
	}

	public void mainMenu() {
		consoleInput = new Scanner(System.in);
		System.out.println("######### FDM BANK #########");
		System.out.println("Enter your Name:");
		name = consoleInput.nextLine();
		System.out.println("Enter your SSN:");
		ssn = consoleInput.nextLine();
		System.out.println("Enter your Address:");
		address = consoleInput.nextLine();
		System.out.println("Enter your TaxId:");
		taxId = consoleInput.nextInt();
	}

}