package com.fdmgroup.bankapp;

import java.math.BigDecimal;

public class PersonalCustomer extends BankCustomer {

	public PersonalCustomer(String name, String ssn, String address, int taxId) {
		super(name, ssn, address, taxId);
	}

	public void resetAccount() {
		for (BankAccount account : accounts) {
			account.setBalance(BigDecimal.ZERO);
		}
	}

}
