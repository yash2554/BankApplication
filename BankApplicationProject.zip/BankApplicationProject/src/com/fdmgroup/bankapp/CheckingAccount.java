package com.fdmgroup.bankapp;

import java.math.BigDecimal;

public class CheckingAccount extends BankAccount {
	private int checkNum = 1;

	public CheckingAccount(CompanyCustomer cust) {

		super(cust);
	}

	public CheckingAccount(PersonalCustomer per) {
		super(per);
	}

	public BigDecimal withdraw(BigDecimal amount) {
		if (amount.compareTo(BigDecimal.ZERO) <= 0) {
			System.out.println("Error:Enter a valid amount");
			return new BigDecimal(0);
		} else {
			BigDecimal balance = super.getBalance().subtract(amount);
			super.setBalance(balance);
			System.out.println("You have withdrawn " + amount + " and your balance is now " + balance);
			return balance;
		}
	}

	public int getCheckNum() {
		return checkNum;
	}

}
